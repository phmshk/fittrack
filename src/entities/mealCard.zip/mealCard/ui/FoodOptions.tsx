import type { FoodEntry } from "@/entities/day";
import { DeleteFood } from "@/features/deleteFood";
import { EditFood } from "@/features/editFood";
import { FoodDetails } from "@/features/foodDetails";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/shared/shadcn/components/ui/dropdown-menu";
import { EllipsisVertical } from "lucide-react";

interface FoodOptionsProps {
  foodEntry: FoodEntry;
}

export const FoodOptions = ({ foodEntry }: FoodOptionsProps) => {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger className="cursor-pointer">
        <EllipsisVertical />
      </DropdownMenuTrigger>
      <DropdownMenuContent>
        <DropdownMenuItem className="flex cursor-pointer items-center gap-1">
          <EditFood food={foodEntry} mealType={foodEntry.mealType} /> Edit
        </DropdownMenuItem>
        <DropdownMenuItem className="flex cursor-pointer items-center gap-1">
          <FoodDetails foodEntry={foodEntry} /> Details
        </DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="flex cursor-pointer items-center gap-1">
          <DeleteFood mealType={foodEntry.mealType} entryId={foodEntry.id} />{" "}
          Delete
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
};
